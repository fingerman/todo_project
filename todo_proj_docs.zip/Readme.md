To-Do Web App (Django Framework)

Tools:

* simple forms with views. Widgets (not model forms)
in this way _form.py_ statements overwrite the field options in _models.py_  
* use the class forms.ModelForm if you might want to skip defining the field
 types of our forms, because we already defined them in the model  
* keep forms, models, urls and views in same dir as it is small app  
* 


Nginx, Gunicorn, Postgres, Django on Docker
* To do: bind static and media files. 
docker-compose.yml - local development    
docker-compose.prod.yml - build in production  
  
#---------------Useful docker commands---------------------------------------------

# NOTE !
To run django env use os.environ package for loading on docker.   
Othewhise with django-environ or etc. they wont be loaded  

`docker-compose -f docker-compose.prod.yml up -d --build	`  		# build in production  

`docker compose exec todo_project python manage.py migrate	`          # make migrations and -> migrate  
`docker exec -it db_image_name psql -U Postgres.`  			# login in DB container as postgres user  
`docker-compose exec db psql --username=user1 --dbname=todo_db`    	# login in the database todo in the db service (container)  

`docker-compose -f docker-compose.prod.yml logs -f`			# view requests logs  
`docker-compose -f docker-compose.prod.yml down -v `			# remove the volumes along with the containers in production  
`docker-compose -f docker-compose.prod.yml down `		        # keep volumes, remove the containers in production   

`docker-compose down -v`





