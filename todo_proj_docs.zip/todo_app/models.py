from django.db import models


class Todo(models.Model):
    title = models.CharField(max_length=30)
    description = models.TextField()
    is_done = models.BooleanField(default=False)
    author = models.CharField(max_length=250, default=False)
    number = models.IntegerField(default=22)
